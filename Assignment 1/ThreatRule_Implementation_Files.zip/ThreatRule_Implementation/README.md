# ThreatRule Lexical Analyzer

## Requirements
- Flex (LEX-compatible scanner generator)
- GCC
- GNU Make
- Python 3 (benchmark data generation only)

## Build
```bash
make
```

## Run
```bash
./threatscanner tests/sample.tr
./threatscanner tests/valid.tr
./threatscanner tests/invalid.tr
./threatscanner tests/extended.tr
```

## Generate benchmark inputs
```bash
python3 generate.py 100
python3 generate.py 1000
python3 generate.py 10000
python3 generate.py 100000
```

## Measure
```bash
for n in 100 1000 10000 100000; do
  /usr/bin/time -f '%e' -o results/time_${n}.txt ./threatscanner tests/rules_${n}.tr > results/output_${n}.txt 2> results/errors_${n}.txt
  printf '%s rules: %s seconds\n' "$n" "$(cat results/time_${n}.txt)"
done
```

The LEX source is `src/threatrule.l`. The generated `lex.yy.c` and executable are build products and should be generated on the submission machine using Flex.
