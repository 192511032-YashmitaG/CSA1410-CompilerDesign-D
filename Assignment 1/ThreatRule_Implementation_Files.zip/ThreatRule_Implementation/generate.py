#!/usr/bin/env python3
"""Generate deterministic valid ThreatRule benchmark files."""
import argparse
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('count', type=int)
p.add_argument('--out-dir', default='tests')
a = p.parse_args()
out = Path(a.out_dir)
out.mkdir(parents=True, exist_ok=True)
path = out / f'rules_{a.count}.tr'
with path.open('w', encoding='utf-8') as f:
    for i in range(a.count):
        f.write(f'RULE rule_{i} IF src_ip == 10.0.0.5 AND port == 22 AND attempts > 5 THEN ALERT "SSH attack detected" ;\n')
print(f'Generated {a.count} rules at {path}')
