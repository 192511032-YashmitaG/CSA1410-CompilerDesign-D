#!/usr/bin/env python3
"""Transparent Python reference harness mirroring the token specification in threatrule.l.
This is not the Flex-generated executable; use `make` on a machine with Flex for that build.
"""
import re, sys
from pathlib import Path

KEYWORDS={'RULE','IF','AND','OR','THEN','ALERT','BLOCK'}
TOKEN_RE=re.compile(r'''(?P<WS>[ \t\r]+)|(?P<NL>\n)|(?P<COMMENT>\#[^\n]*|//[^\n]*)|(?P<URL>https?://[^\s"<>;]+)|(?P<CVE>CVE-[0-9]{4}-[0-9]{4,})|(?P<FILE_HASH>(?:[0-9A-Fa-f]{32}|[0-9A-Fa-f]{40}|[0-9A-Fa-f]{64}))|(?P<IP_ADDRESS>[0-9]+(?:\.[0-9]+){3})|(?P<STRING>"(?:[^"\\\n]|\\.)*")|(?P<UNTERM>"(?:[^"\\\n]|\\.)*(?:\n|$))|(?P<REL>==|!=|<=|>=|<|>)|(?P<INTEGER>[0-9]+)|(?P<ID>[A-Za-z_][A-Za-z0-9_]*)|(?P<SEMICOLON>;)|(?P<DELIM>[(),])|(?P<OTHER>.)''',re.M)

def scan(path, show=True):
    data=Path(path).read_text(encoding='utf-8')
    line=1; tokens=0; errors=0; symbols=[]; seen=set(); rows=[]
    for m in TOKEN_RE.finditer(data):
        typ=m.lastgroup; lex=m.group(); ln=line
        if typ=='NL': line+=1; continue
        if typ in ('WS','COMMENT'): continue
        if typ=='UNTERM':
            errors+=1; rows.append(f'LEXICAL ERROR line {ln}: unterminated string [{lex.rstrip()}]')
            line += lex.count('\n'); continue
        if typ=='OTHER':
            errors+=1; rows.append(f'LEXICAL ERROR line {ln}: invalid character [{lex}]')
            line += lex.count('\n'); continue
        if typ=='IP_ADDRESS':
            octets=[int(x) for x in lex.split('.')]
            if any(x>255 for x in octets):
                errors+=1; rows.append(f'LEXICAL ERROR line {ln}: invalid IPv4 address [{lex}]')
                continue
        if typ=='ID' and lex in KEYWORDS: typ='KEYWORD'
        elif typ=='ID':
            typ='IDENTIFIER'
            if lex not in seen: seen.add(lex); symbols.append(lex)
        elif typ=='REL': typ='RELATIONAL_OPERATOR'
        rows.append(f'{ln:5d}  {typ:<24} {lex}')
        tokens+=1
        line += lex.count('\n')
    rows += ['',f'Total tokens: {tokens}',f'Total lexical errors: {errors}',f'Unique identifiers: {len(symbols)}']
    if show: print('\n'.join(rows))
    return tokens,errors,rows

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('Usage: python3 reference_scanner.py input-file')
    t,e,_=scan(sys.argv[1]); raise SystemExit(1 if e else 0)
